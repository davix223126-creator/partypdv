# PartyPdv — MVP para GitHub Pages

## Como abrir
Abra `index.html` no navegador ou publique-o no GitHub Pages.

## Como publicar
1. Crie um repositório no GitHub.
2. Envie `index.html` e este `README.md` para a raiz do repositório.
3. Acesse **Settings → Pages**.
4. Em **Build and deployment**, selecione a branch principal e a pasta `/ (root)`.
5. Salve e aguarde a URL do GitHub Pages.

## Funcionalidades incluídas
- Interface responsiva inspirada no modelo enviado.
- Site público de apresentação e painel administrativo.
- PDV/carrinho e registro de vendas.
- Produtos e estoque.
- Clientes, eventos, dívidas e pagamentos parciais.
- Rascunhos de contratos e impressão pelo navegador.
- Relatórios simples, despesas, importação/exportação de backup JSON.
- Personalização de nome, cores e tema.
- Party IA com respostas predefinidas por palavras-chave.
- Dados salvos localmente no navegador.

## Limitações importantes
Este é um MVP front-end. Os dados ficam no navegador atual e não sincronizam entre dispositivos. Não há autenticação real, banco de dados remoto, isolamento multiempresa, cobrança online, chaves seguras de ativação, assinatura eletrônica, emissão fiscal ou integração com modelo generativo. Não use dados sensíveis ou financeiros reais nesta versão.

Para produção, implemente backend seguro, autenticação, autorização por empresa, backups e integrações externas. Nunca coloque segredos no JavaScript público.
